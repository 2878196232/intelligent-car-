#include "headfile.h"
#include "adc.h"
#include <math.h>

#define ADC_NUM     12    //һ�βɼ�����

#define ADC3_NUM		2			//�����ƽ�������С
#define ADC3_NUM_For		8		//������жϴ���

//���Ե��ϵ��
#define ADC_KP_1    50		//KP1 ָ����Ȩ  7.6	
#define ADC_KP_2    40.0
#define ADC_KP_3 400    

#define ADC_error1 10				//L-R=error
#define ADC_error2 0
#define ADC_error3 200

#define ADC_error_1and3_A   1000
#define ADC_error_1and3_B   1000
#define ADC_error_1and3_C   500
#define ADC_error_1and3_P   1000

float MAX_esp=7;			//ָ���޷�
float ADC_xianfu=1000;

#define  us      40    //�ɼ��ӳ�40us

int ADC1_flag=0;
int adc_data3[ADC3_NUM][2];
float aver_dataL=0;
float aver_dataR=0;
int ADC1_exp=0;

int16  adc_data[ADC_NUM][2];                //�����вɼ�ֵ ԭʼֵ8�����

float adc1=0;
float ADC_KP_3_lingshi=0;
float ADC_KP_1_lingshi=0;
//int16  Left_Adc=0,Right_Adc=0;      //           ���ҵ��ֵ

void ADC_Init_All()
{
	adc_init(ADC_P00,ADC_SYSclk_DIV_32);   //32��Ƶ��750KHZ   1.3us�ɼ�һ��
	adc_init(ADC_P01,ADC_SYSclk_DIV_32);
	adc_init(ADC_P05,ADC_SYSclk_DIV_32);
	adc_init(ADC_P06,ADC_SYSclk_DIV_32);
	adc_init(ADC_P13,ADC_SYSclk_DIV_32);
	adc_init(ADC_P14,ADC_SYSclk_DIV_32);
}

int normalize_data_1and3()
{
	int i=0;
	
//	float sumL1=0,sumR1=0;
	float sumL3=0,sumR3=0;
	
	int32 error=0;
	
//	float maxL1=-100,maxR1=-100;
//	float minL1=10000,minR1=10000;
	
	float maxL3=-100,maxR3=-100;
	float minL3=10000,minR3=10000;
	
//	for(i=0;i<ADC_NUM;i++)
//		{
//			adc_data[i][0]=adc_once(ADC_P00,ADC_12BIT);
//			adc_data[i][1]=adc_once(ADC_P01,ADC_12BIT);
//			maxL1=maxL1 > adc_data[i][0] ? maxL1:adc_data[i][0];
//			minL1=minL1 < adc_data[i][0] ? minL1: adc_data[i][0];
//			maxR1=maxR1 > adc_data[i][1] ? maxR1:adc_data[i][1];
//			minR1=minR1 < adc_data[i][1] ? minR1: adc_data[i][1];
//			sumL1+=adc_data[i][0];
//			sumR1+=adc_data[i][1];
//			delay_us(us);
//		}
//		sumL1=sumL1/(ADC_NUM-2)+ADC_error1;
//		sumR1=sumR1/(ADC_NUM-2);
//	
		
	aver_ADC3();
//	oled_int16(1,1,aver_dataL);
//		oled_int16(1,2,aver_dataR);
//  	oled_int16(1,3,ADC1_flag);
//		oled_int16(1,3,aver_dataL-aver_dataR);
	for(i=0;i<ADC_NUM;i++)
		{
			adc_data[i][0]=adc_once(ADC_P13,ADC_12BIT);
			adc_data[i][1]=adc_once(ADC_P14,ADC_12BIT);
			maxL3=maxL3 > adc_data[i][0] ? maxL3:adc_data[i][0];
			minL3=minL3 < adc_data[i][0] ? minL3: adc_data[i][0];
			maxR3=maxR3 > adc_data[i][1] ? maxR3:adc_data[i][1];
			minR3=minR3 < adc_data[i][1] ? minR3: adc_data[i][1];
			sumL3+=adc_data[i][0];
			sumR3+=adc_data[i][1];
			delay_us(us);
		}
		sumL3=sumL3/(ADC_NUM-2)+ADC_error3;
		sumR3=sumR3/(ADC_NUM-2);
		
		
		
//		if(ADC_KP_1*((aver_dataL-aver_dataR)/(aver_dataL+aver_dataR))>=MAX_esp)
//		{
//			ADC1_exp=ADC_xianfu;
//		}
//		else if(ADC_KP_1*((aver_dataL-aver_dataR)/(aver_dataL+aver_dataR))<=-1*MAX_esp)
//		{
//			ADC1_exp=-1*ADC_xianfu;
//		}
//		else
//		{
//			
//			ADC1_exp=exp(ADC_KP_1*((aver_dataL-aver_dataR)/(aver_dataL+aver_dataR)))-exp(-1*ADC_KP_1*((aver_dataL-aver_dataR)/(aver_dataL+aver_dataR)));
//			
//		}
		
		//error=((ADC_error_1and3_A*(sumL3-sumR3)+ADC_error_1and3_B*(sumL1-sumR1))/(ADC_error_1and3_A*(sumL3+sumR3)+ADC_error_1and3_C*abs(sumL1-sumR1)))*ADC_error_1and3_P;
		//error=((ADC_error_1and3_A*(sumL3-sumR3))/(ADC_error_1and3_A*(sumL3+sumR3)));
		//error=normalize_date(select_ADC_3)+ADC_KP_1*((aver_dataL-aver_dataR)/(aver_dataL+aver_dataR));
		
		
		
//		error=(normalize_date(select_ADC_3)+ADC1_exp);
				
				adc1=(aver_dataL-aver_dataR)/(aver_dataL+aver_dataR);
				
				ADC_KP_3_lingshi=ADC_KP_3-150*adc1;
				ADC_KP_1_lingshi=500-ADC_KP_3_lingshi;
	error=(normalize_date(select_ADC_3)+ADC_KP_1_lingshi*adc1);
	
	//error=(ADC_KP_3*(sumL3+ADC_error3-sumR3)+ADC_KP_1*(aver_dataL-aver_dataR))/(sumL3+sumR3);
		//error=(sumL3-sumR3);
		
		//error=(ADC1_exp);
		return error;
	
}

void ADC3_data(int *aver_sumL,int *aver_sumR)
{
	int i=0;
	
	int sumL=0,sumR=0;
	int ADCL=0,ADCR=0;
	ADCL=adc_once(ADC_P00,ADC_12BIT);
	ADCR=adc_once(ADC_P01,ADC_12BIT);

	for(i=0;i<ADC3_NUM;i++)
	{
		if(i==ADC3_NUM-1)
		{
			adc_data3[i][0]=ADCL;
		}
		else
		{
			adc_data3[i][0]=adc_data3[i+1][0];
		}
		sumL+=adc_data3[i][0];
	}
	
	for(i=0;i<ADC3_NUM;i++)
	{
		if(i==ADC3_NUM-1)
		{
			adc_data3[i][1]=ADCR;
		}
		else
		{
			adc_data3[i][1]=adc_data3[i+1][1];

		}
		sumR+=adc_data3[i][1];
	}
	
	*aver_sumL=(sumL/ADC3_NUM);
	*aver_sumR=(sumR/ADC3_NUM);
}

void aver_ADC3()
{
	int i=0;
	
	int flagL=0;
	int flagR=0;
	
	int ADCL_first;
	int ADCR_first;
	
	int ADCL;
	int ADCR;
	
	float sumL=0,sumR=0;
	
//	ADC3_data(&ADCL_first,&ADCR_first);
	ADCL_first=adc_once(ADC_P00,ADC_12BIT);
	ADCR_first=adc_once(ADC_P01,ADC_12BIT);
	sumL+=ADCL_first;
	sumR+=ADCR_first;
	ADC3_data(&ADCL,&ADCR);
	sumL+=ADCL;
	sumR+=ADCR;
	
	if(ADCL_first<ADCL)
	{
		flagL=1;
	}
	else
	{
		flagL=-1;
	}
	
	if(ADCR_first<ADCR)
	{
		flagR=1;
	}
	else
	{
		flagR=-1;
	}

	for(i=0;i<ADC3_NUM_For-2;i++)
	{
		ADCL_first=ADCL;
		ADCR_first=ADCR;
		ADC3_data(&ADCL,&ADCR);
		
		//
		if(flagL==1 && (ADCL_first < ADCL))
		{
			flagL=1;
			
		}
		else if(flagL==1 && (ADCL_first > ADCL))
		{
			flagL=0;		
		}
		
		if(flagL==-1 && (ADCL_first > ADCL))
		{
			flagL=-1;
		}
		else if(flagL==-1 && (ADCL_first < ADCL))
		{
			flagL=0;
			
		}
		sumL+=ADCL;
		//
		
		if(flagR==1 && (ADCR_first < ADCR))
		{
			flagR=1;
		}
		else if(flagR==1 && (ADCR_first > ADCR))
		{
			flagR=0;
		}
		
		if(flagR==-1 && (ADCR_first > ADCR))
		{
			flagR=-1;
		}
		else if(flagR==-1 && (ADCR_first < ADCR))
		{
			flagR=0;
		
		}
		sumR+=ADCR;
		
	}
	
	if(flagL==1 || flagL==-1)
	{
		aver_dataL=(sumL/ADC3_NUM_For)+ADC_error1;
	}
	
	if(flagR==1 || flagR==-1)
	{
		aver_dataR=(sumR/ADC3_NUM_For);
	}
	
	
	if(flagL==0)
	{
		ADC1_flag=flagR*2;
	}
	
	if(flagR==0)
	{
		ADC1_flag=flagL;
	}
	
	if(flagR==0 && flagL==0)
	{
		ADC1_flag=0;
	}
	
	if(flagR!=0 &&flagL!=0)
	{
		ADC1_flag=3;
	}
	
	
}

int normalize_date(select_ADC select_ADC)
{
	float maxL=-100,maxR=-100;
	float minL=10000,minR=10000;
	float sumL=0,sumR=0;
	
	int i=0;
	if(select_ADC == select_ADC_1)
	{
		float sum=0;
		for(i=0;i<ADC_NUM;i++)
		{
			adc_data[i][0]=adc_once(ADC_P00,ADC_12BIT);
			adc_data[i][1]=adc_once(ADC_P01,ADC_12BIT);
			maxL=maxL > adc_data[i][0] ? maxL:adc_data[i][0];
			minL=minL < adc_data[i][0] ? minL: adc_data[i][0];
			maxR=maxR > adc_data[i][1] ? maxR:adc_data[i][1];
			minR=minR < adc_data[i][1] ? minR: adc_data[i][1];
			sumL+=adc_data[i][0];
			sumR+=adc_data[i][1];
			delay_us(us);
		}
		sumL=sumL/(ADC_NUM-2)+ADC_error1;
		sumR=sumR/(ADC_NUM-2);
		return (ADC_KP_1*(sumL-sumR)/(sumL+sumR));
	}
	else if(select_ADC == select_ADC_2)
	{
		for(i=0;i<ADC_NUM;i++)
		{
			adc_data[i][0]=adc_once(ADC_P05,ADC_12BIT);
			adc_data[i][1]=adc_once(ADC_P06,ADC_12BIT);
			maxL=maxL > adc_data[i][0] ? maxL:adc_data[i][0];
			minL=minL < adc_data[i][0] ? minL: adc_data[i][0];
			maxR=maxR > adc_data[i][1] ? maxR:adc_data[i][1];
			minR=minR < adc_data[i][1] ? minR: adc_data[i][1];
			sumL+=adc_data[i][0];
			sumR+=adc_data[i][1];
			delay_us(us);
		}
		sumL=sumL/(ADC_NUM-2)+ADC_error2;
		sumR=sumR/(ADC_NUM-2);
		return (ADC_KP_2*(sumL-sumR)/(sumL+sumR));
	}
	else if(select_ADC == select_ADC_3)
	{
		for(i=0;i<ADC_NUM;i++)
		{
			adc_data[i][0]=adc_once(ADC_P13,ADC_12BIT);
			adc_data[i][1]=adc_once(ADC_P14,ADC_12BIT);
			maxL=maxL > adc_data[i][0] ? maxL:adc_data[i][0];
			minL=minL < adc_data[i][0] ? minL: adc_data[i][0];
			maxR=maxR > adc_data[i][1] ? maxR:adc_data[i][1];
			minR=minR < adc_data[i][1] ? minR: adc_data[i][1];
			sumL+=adc_data[i][0];
			sumR+=adc_data[i][1];
			delay_us(us);
		}
		sumL=sumL/(ADC_NUM-2)+ADC_error3;
		sumR=sumR/(ADC_NUM-2);
		//return (ADC_KP_3*(sumL-sumR)/(sumL+sumR));
		return (ADC_KP_1_lingshi*(sumL-sumR)/(sumL+sumR));
		}
	else
	{
		return 0;
	}
}

void normalize_date_All(int16 *ADC1,int16 *ADC2,int16 *ADC3)
{
	*ADC1=normalize_date(select_ADC_1);
	*ADC2=normalize_date(select_ADC_2);
	*ADC3=normalize_date(select_ADC_3);
}

void date(select_ADC select_ADC,int16 *ADCL,int16 *ADCR)
{
	if(select_ADC==select_ADC_1)
	{
		*ADCL=adc_once(ADC_P00,ADC_12BIT);
		*ADCR=adc_once(ADC_P01,ADC_12BIT);
		delay_us(us);
	}
	else if(select_ADC==select_ADC_2)
	{
		*ADCL=adc_once(ADC_P05,ADC_12BIT);
		*ADCR=adc_once(ADC_P06,ADC_12BIT);
		delay_us(us);
	}
	else if(select_ADC==select_ADC_3)
	{
		*ADCL=adc_once(ADC_P13,ADC_12BIT);
		*ADCR=adc_once(ADC_P14,ADC_12BIT);
		delay_us(us);
	}
	
	
}


//		if(flagL==1 && (ADCL_first < ADCL))
//		{
//			flagL=1;
//			sumL+=ADCL;
//			oled_int16(1,4,flagL);
//			
//		}
//		else if(flagL==1 && (ADCL_first > ADCL));
//		{
//			flagL=0;
//			
//		}
//		oled_int16(64,4,flagL);
//		if(flagL==-1 && (ADCL_first > ADCL))
//		{
//			flagL=-1;
//			sumL+=ADCL;
//		}
//		else if(flagL==-1 && (ADCL_first < ADCL));
//		{
//			flagL=0;
//		}
//		
//		//
//		
//		if(flagR==1 && (ADCR_first < ADCR))
//		{
//			flagR=1;
//			sumR+=ADCR;
//		}
//		else if(flagR==1 && (ADCR_first > ADCR));
//		{
//			flagR=0;
//		}
//		
//		if(flagR==-1 && (ADCR_first > ADCR))
//		{
//			flagR=-1;
//			sumR+=ADCR;
//		}
//		else if(flagR==-1 && (ADCR_first < ADCR));
//		{
//			flagR=0;
//		}