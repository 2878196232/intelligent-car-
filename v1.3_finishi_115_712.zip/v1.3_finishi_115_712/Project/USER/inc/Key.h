#ifndef __KEY_H_
#define __KEY_H_

typedef enum
{
	key_1,
	key_2,
	key_3,
	key_4,
	key_null
	
	
}key_enum;


void Key_init();
key_enum key_scan();
void menu();
void buzzer_Init();












#endif