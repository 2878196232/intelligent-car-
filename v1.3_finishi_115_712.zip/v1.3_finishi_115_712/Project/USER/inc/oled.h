#ifndef _OLED_H_
#define _OLED_H_
//#include "control.h"

//extern int32 error;
//extern int32 ADC_error_1and3;

//extern uint16 motor_UK;

//extern float aver_dataL;
//extern float aver_dataR;

extern int ADC3L;
extern int ADC3R;
//extern int ADC1_exp;


void show();
void wireless_show();



#endif