#ifndef __CONTROL_H_
#define __CONTROL_H_
#include "headfile.h"


void huan_Control();
void PID_control();
extern int currentState;			//����ȫ��״̬����־λ
extern unsigned char status;
extern int motor_UK ;
extern int sum_Left;
extern int motor_UK_Target_L;
extern int motor_UK_Target_R;
extern int flag_HD_L;
extern int flag_HD_R;
extern signed long ADC_error_1and3;
extern float Target_angle_RH_L;
extern float Target_angle_CH_L;
extern float Current_angle_RH_L;
extern float Current_angle_CH_L;
extern float piancha_angle_H;
extern float Target_zj_L;
extern float Target_zj_R;

extern float Target_angle_RH_R;
extern float Target_angle_CH_R;
extern float Current_angle_RH_R;
extern float Current_angle_CH_R;

extern float zhuanXiangPID_P1;
extern float zhuanXiangPID_P2;
extern float zhuanXiangPID_D1;
extern float zhuanXiangPID_D2;

extern float zhuanXiangwangPID_P1;
extern float zhuanXiangwangPID_P2;	
extern float zhuanXiangwangPID_D1;
extern float zhuanXiangwangPID_D2;



int Velocity_Control_L(int encoder);
int Velocity_Control_R(int encoder);
int Yaw_Control(float currentAngle,float targetAngle);
#endif