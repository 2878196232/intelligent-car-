#include "control.h"
#include "adc.h"
#include "motor.h"
#include "headfile.h"
#include "math.h"
#include "Key.h"
#include "ware.h"
//3�Ե�й�һ�����ݼ�����
int16 ADC_data_1=0;
int16 ADC_data_2=0;
int16 ADC_data_3=0;


//140
//float zhuanXiangPID_P1 = 1.5;
//float zhuanXiangPID_P2 = 0;
//float zhuanXiangPID_D1 = 20;
//float zhuanXiangPID_D2 = 1;

//float zhuanXiangwangPID_P1=0;
//float zhuanXiangwangPID_P2=0;	
//float zhuanXiangwangPID_D1=0;
//float zhuanXiangwangPID_D2=0;

//90
float zhuanXiangPID_P1 = 1.4;
float zhuanXiangPID_P2 = 0.0022;
float zhuanXiangPID_D1 = 18;
float zhuanXiangPID_D2 = 0.3;

float zhuanXiangwangPID_P1=0;
float zhuanXiangwangPID_P2=0;	
float zhuanXiangwangPID_D1=0;
float zhuanXiangwangPID_D2=0;

float jiansuPID_P = 0;
float jiansuPID_I = 0;
float jiansuPID_D = 0;

//���ٴ���
int jianshu_flag1=0;
int jianshu_flag2=0;
int jianshu_1=0;   //40
int jianshu_2=0;		//20
int jianshu_1_zhi=0;    //6500
int jianshu_2_zhi=0;			//3500
int jianshu_lingshi;

//ADC
float PD_error=-12;       //-12

int32 ADC_error_1=0;
int32 ADC_error_1_last=0;

int32 ADC_error_2=0;
int32 ADC_error_2_last=0;

int32 ADC_error_3=0;
int32 ADC_error_3_last=0;

signed long ADC_error_1and3=0;
signed long ADC_error_1and3_last=0;
//�ٶ�PI

////KP�Ǽ��ٶ� KIԽ�󣬵õ���ֵԽ��

float L_Velocity_KP=60,L_Velocity_KI=0.7,L_Velocity_KD=3;    // �ٶȱջ���ʵ����Ҫ���ڣ�Ħ������һ������ֵҲ��һ��
float R_Velocity_KP=65,R_Velocity_KI=0.7,R_Velocity_KD=3; 

////190 ��
//int L_Velocity_KP=-38,L_Velocity_KI=-7.7;    // �ٶȱջ���ʵ����Ҫ���ڣ�Ħ������һ������ֵҲ��һ��
//int R_Velocity_KP=-38,R_Velocity_KI=-7.7;    // �ٶȱջ���ʵ����Ҫ���ڣ�Ħ������һ������ֵҲ��һ��   






int PID_error;




//���ߴ���
int left_V=0;//���߱�־λ
int right_V=0;
int left_right_min=0;//2400


int left_P=0;
int right_P=0;

int left_2=0;
int right_2=0;

int aver_sumL;
int aver_sumR;

int sum_Left=0;
int sum_Right=0;

unsigned char status = 0;

//ֱ���ж�
int L_zhixian=2200;    //2200
int R_zhixian=2200;


//������־λ
int left_huan=0;
int right_huan=0;

int left_huan_zi=5400;
int right_huan_zi=5400;

float huan_distance;
float huan_distance_target=0.30;

int huan_init_pingbi=100;

int huan_pingbi=0;   //Բ������
int huan_pingbi_num=150;  //Բ���������δ���

int huan_left_motor=0.5;
int huan_right_motor=0.3;

int huan_left_motor_lingshi=0;
int huan_right_motor_lingshi=0;


int HD_time = 0;
float Target_zj_L = 0;
float Target_zj_R = 0;


//������ٶ�
int motor_UK=115;      //���ٶ�160
int motor_UK_Target_L;
int motor_UK_Target_R;
int motor_L=0;
int motor_R=0;
int motor_L_last;
int motor_R_last;
int motor_UK_lingshi;

int motor_L_jiansu;
int motor_R_jiansu;

int ECPULSE1 = 0;          // �����������ȫ�ֱ���
int ECPULSE2 = 0;          // �����ұ�����ȫ�ֱ���
//extern int error;

float Kp_angle = 1.5;//���������ף�1.5��0.3��0.5
float Ki_angle = 0.3;
float Kd_angle = 0.5;


//�����ǲ���

float Gyro=0;  
float Gyro_last=0;  

//��������
float Target_angle_RH_L = 0;
float Target_angle_CH_L = 0;
float Current_angle_RH_L = 0;
float Current_angle_CH_L = 0;

float Target_angle_RH_R = 0;
float Target_angle_CH_R = 0;
float Current_angle_RH_R = 0;
float Current_angle_CH_R = 0;

int HD_left_speed = 0;
int HD_right_speed = 0;

float piancha_angle_H =0;
int HD_Speed = 1800;
int KP_hd = 50;

int flag_HD_L = 0;
int flag_HD_R = 0;
int flag_filish = 0;
int reg_HD_L = 0;
int reg_HD_R = 0;

int index_L = 0;
int index_R = 0;



void PID_control()
{
	static int pid_t = 0;
	pid_t += 5;
	//motor_setPWM(motor_UK,1,motor_UK,1);
	//�ɼ���������ֵ
	//ctimer_find(& ECPULSE1,& ECPULSE2);
	
	date(select_ADC_1,&left_P,&right_P);
	//date(select_ADC_3,&left_V,&right_V);
	date(select_ADC_2,&left_2,&right_2);
//	sum_Left=left_P+left_V+left_2;
//	sum_Right=right_P+right_V+right_2;
	
		sum_Left=left_P+adc_once(ADC_P16,ADC_12BIT)+left_2;
	sum_Right=right_P+adc_once(ADC_P16,ADC_12BIT)+right_2;

//	if(pid_t % 10 == 0)
	if(1)
	{
		pid_t = 0;
		if((sum_Left<left_right_min || sum_Right<left_right_min) && abs(sum_Left-sum_Right) <550 )    //&& (((left_V>right_V) && (left_P>right_P)) || ((left_V<right_V) && (left_P<right_P)))    (left_V+right_V)<left_right_min
		{
			if(((left_V>right_V) && (left_P>right_P)))
			{
				ADC_error_1and3=35;
	//			PID_error=ADC_KP_1and3_zhi*ADC_error_1and3+ADC_KD_1and3_zhi*(ADC_error_1and3-ADC_error_1and3_last)+Gyro_KD*(Gyro-Gyro_last);
	//			motor_UK_Target_L=1000;
	//			motor_UK_Target_R=700;
				
			}
			if(((left_V<right_V) && (left_P<right_P)))
			{
				ADC_error_1and3=-35;
	//			PID_error=ADC_KP_1and3_zhi*ADC_error_1and3+ADC_KD_1and3_zhi*(ADC_error_1and3-ADC_error_1and3_last)+Gyro_KD*(Gyro-Gyro_last);
	//			motor_UK_Target_L=700;
	//			motor_UK_Target_R=1000;
			}
			
		}
	//	else if((left_P<L_zhixian || right_P<R_zhixian) && abs(left_P-right_P) >500)
	//	{
	//		ADC_error_1and3=normalize_data_1and3()+PD_error;
	//		PID_error=zhuanXiangwangPID_P1*ADC_error_1and3+zhuanXiangwangPID_P2*ADC_error_1and3*abs(ADC_error_1and3)+zhuanXiangwangPID_D1*(ADC_error_1and3-ADC_error_1and3_last)+zhuanXiangwangPID_D2*(-num_gryo_z);
	//		motor_UK_Target_L=motor_UK_lingshi- PID_error;
	//		motor_UK_Target_R=motor_UK_lingshi+ PID_error;
	//	}
		else    //ֱ�ߴ���
		{
			if(jianshu_lingshi!=0)
			{
				--jianshu_lingshi;
				if(jianshu_flag2==1)
				{
					motor_UK_lingshi=motor_UK-jianshu_2_zhi;
				}
				if(jianshu_flag1==1)
				{
					motor_UK_lingshi=motor_UK-jianshu_1_zhi;
				}
			}
			else
			{
				jianshu_flag1=0;
				jianshu_flag2=0;
				motor_UK_lingshi=motor_UK;
			}
			ADC_error_1and3=normalize_data_1and3()+PD_error;
//			ADC_error_1and3 = filter(ADC_error_1and3);
				PID_error=zhuanXiangPID_P1*ADC_error_1and3+zhuanXiangPID_P2*ADC_error_1and3*abs(ADC_error_1and3)+zhuanXiangPID_D1*(ADC_error_1and3-ADC_error_1and3_last)+zhuanXiangPID_D2*(-num_gryo_z);
				motor_UK_Target_L=motor_UK_lingshi- PID_error;
				motor_UK_Target_R=motor_UK_lingshi+ PID_error;
			}
	}
	
	
//	motor_UK_Target_L=0;    //�Ƕȱջ�����
//	motor_UK_Target_R=0;
//	ADC_error_1and3=-65;
//	Gyro_error=1*Gyro_Control(Gyro);
//	motor_UK_Target_L-=Gyro_error;
//	motor_UK_Target_R+=Gyro_error;
	
//	if(num_pitch>=15&&num_pitch<=26)
//	{
//		motor_UK_Target_L+=40;
//		motor_UK_Target_R+=40;
//	}
	
	
	if(PID_error>0)		//�����ݷ���������ֲ���
	{
		motor_L = Velocity_Control_L(ECPULSE1);
		motor_R = Velocity_Control_R(ECPULSE2);
  }
	else
	{
		motor_L = Velocity_Control_L(ECPULSE1);
		motor_R = Velocity_Control_R(ECPULSE2);
	}
//	if(((left_V>right_V) && (left_P>right_P)))
//	{
//		motor_UK = -100;
//	}
//	if(((left_V<right_V) && (left_P<right_P)))
//	{
//		motor_UK = -100;
//	}
//	else
//	{
//		motor_UK = 140;
//	}
	
//	if(flag_filish !=1)
	huan_Control();   //����
	
	
	
	if(motor_L>=8500)   //PWM ��������
	{
		motor_L=8500;
	}
	else if(motor_L<=-8500)
	{
		motor_L=-8500;
	}
	
	if(motor_R>=8500)
	{
		motor_R=85000;
	}
	else if(motor_R<=-8500)
	{
		motor_R=-8500;
	}
	
//	if(motor_R>=0)
//	{
//		motor_R=motor_R+500;
//	}
//	else
//	{
//		motor_R=motor_R-500;
//	}
//	
//	if(motor_L>=0)
//	{
//		motor_L=motor_L+500;
//	}
//	else
//	{
//		motor_L=motor_L-500;
//	}
	
//	
//		motor_UK_Target_L=170;
//		motor_UK_Target_R=170;
//		motor_L = Velocity_Control_L(ECPULSE1);    //�������ջ�����
//		motor_R = Velocity_Control_R(ECPULSE2);
	
	
	if(index_L == 1 && index_R == 0)
	{
		if(flag_HD_L == 2   || flag_HD_L == 0  )//|| flag_filish == 1
			motor_setPWM_fangxiang(motor_L,motor_R);
	}
	else if(index_L == 0 && index_R == 1)
	{
		if(flag_HD_R == 2   || flag_HD_R == 0  )//|| flag_filish == 2
			motor_setPWM_fangxiang(motor_L,motor_R);
	}
	else if(index_L == 0 && index_R == 0)
	{
		motor_setPWM_fangxiang(motor_L,motor_R);
	}
		
//	motor_setPWM_fangxiang(1500,-1500);
//	motor_setPWM(1800,1,1800,1);
	

	Gyro_last=Gyro;
	ADC_error_1and3_last=ADC_error_1and3;
	
		//���ֵ����
	motor_L_last=motor_L;
	motor_R_last=motor_R;

}


//***********����Ԫ��******************//

void huan_Control()
{
	Current_angle_RH_L = num_yaw;//���뻷��ȡ�Ƕ�
	

	
	if(huan_init_pingbi!=0)//����
	{
		huan_init_pingbi--;
		return;
		
	}


	if(sum_Left>=5860)//���뻷
	{
			
		if(left_huan==0&&right_huan==0)   
		{			
			
			huan_pingbi=huan_pingbi_num;
			if(reg_HD_L == 0)
		{
			
			if(Current_angle_RH_L>355) Current_angle_RH_L = 0;
				Target_angle_RH_L = Current_angle_RH_L + 50;
				Target_zj_L = Current_angle_RH_L;
				reg_HD_L = 1;
				index_L = 1;
			
		}
	
	if(Target_angle_RH_L>360)
	{
		Target_angle_RH_L -= 360;
	}
			flag_HD_L = 1;
		}	
		
	}
	
	if(flag_HD_L == 1)
	{
		
		if(abs(Current_angle_RH_L-Target_angle_RH_L)<5)
			{
					HD_time++;
			}
			else
			{
							piancha_angle_H=Yaw_Control(Current_angle_RH_L,Target_angle_RH_L);
							HD_left_speed = 	HD_Speed - KP_hd*piancha_angle_H;  
							HD_right_speed =	HD_Speed + KP_hd*piancha_angle_H;
							motor_setPWM_fangxiang(HD_left_speed,HD_right_speed);
			}
			if(HD_time>=4)
			{
				left_huan=1;
				flag_HD_L = 2;
				reg_HD_L = 0;
				HD_time = 0;
			}
	}

	Current_angle_CH_L = num_yaw;//�������ȡ

	if(fabs(Current_angle_CH_L - Target_zj_L) < 3)//�����sum_Right>=3820 && sum_Right <=3920
	{
		
		if(right_huan==0&&left_huan==1)  
			{
				huan_pingbi=huan_pingbi_num;
				
					if(reg_HD_L == 0)
				{
			
					if(Current_angle_CH_L>355) Current_angle_CH_L = 0;
							Target_angle_CH_L = Current_angle_CH_L-5;
							reg_HD_L = 1;
			
				}
	

					if(Target_angle_CH_L<0)
				{
					Target_angle_CH_L += 360;
				}

					flag_HD_L = 3;
				
					reg_HD_L = 0;
			}	
					
		}
	
	
	
	if(flag_HD_L == 3)
	{
//		if(abs(Current_angle_CH_L-Target_angle_CH_L)<3)
//			{
//					HD_time++;
//			}
//			else
//			{
//							piancha_angle_H=Yaw_Control(Current_angle_CH_L,Target_angle_CH_L);
//							HD_left_speed = 	HD_Speed - KP_hd*piancha_angle_H;  
//							HD_right_speed =	HD_Speed + KP_hd*piancha_angle_H;
//						
//							motor_setPWM_fangxiang(HD_left_speed,HD_right_speed);
//			}
			HD_time++;
			motor_setPWM_fangxiang(1000,1000);
			if(HD_time>=20)
			{
							left_huan=0;
							flag_HD_L = 4;
							//flag_filish = 1;
							index_L = 0;
							HD_time=0;
			}
	}
	
	Current_angle_RH_R = num_yaw;//���뻷��ȡ
	
	if(sum_Right>=5790)//���뻷
	{
			
		if(right_huan==0&&left_huan==0)   
		{			
			
				huan_pingbi=huan_pingbi_num;
			
				if(reg_HD_R == 0)
			{
				
				if(Current_angle_RH_R>355) Current_angle_RH_R = 0;
					Target_angle_RH_R = Current_angle_RH_R - 40;
					Target_zj_L = Current_angle_RH_R;
					reg_HD_R = 1;
				
			}
		
			if(Target_angle_RH_R<0)
			{
				Target_angle_RH_R +=360; 
			}
				flag_HD_R = 1;
				index_R = 1;
		}	
		
	}
	
	if(flag_HD_R == 1)
	{
		if(abs(Current_angle_RH_R-Target_angle_RH_R)<2)
			{
							HD_time++;

			}
			else
			{
							piancha_angle_H=Yaw_Control(Current_angle_RH_R,Target_angle_RH_R);
							HD_left_speed = 	HD_Speed - KP_hd*piancha_angle_H;  
							HD_right_speed =	HD_Speed + KP_hd*piancha_angle_H;
						
							motor_setPWM_fangxiang(HD_left_speed,HD_right_speed);
			}
			
			if(HD_time>=3)
			{
							right_huan=1;
							flag_HD_R = 2;
							reg_HD_R = 0;
			}
	}

	Current_angle_CH_R = num_yaw;//�ҳ�����ȡ

	if(fabs(Current_angle_CH_R -Target_zj_L) < 3)//�ҳ���sum_Right>=3830
	{
		
		if(right_huan==1&&left_huan==0)  
			{
				huan_pingbi=huan_pingbi_num;
				
			if(reg_HD_R == 0)
		{
			
			if(Current_angle_CH_R>355) Current_angle_CH_R = 0;
//				Target_angle_CH_R = Current_angle_CH_R-20;
				Target_angle_CH_R = Current_angle_CH_R+13;
				reg_HD_R = 1;
			
		}
	
//		if(Target_angle_CH_R<0)
//	{
//		Target_angle_CH_R +=360; 
//	}
	
		if(Target_angle_CH_R>360)
	{
		Target_angle_CH_R -=360; 
	}
	
	else
	{
		Target_angle_CH_R = Target_angle_CH_R;
	}
			flag_HD_R = 3;
		}	
			
	}
	
	
	
	if(flag_HD_R == 3)
	{
//		if(abs(Current_angle_CH_R-Target_angle_CH_R)<5)
//			{
//							left_huan=0;
//							flag_HD_R = 4;
//							//flag_filish = 2;
//							index_R = 0;
//			}
//			else
//			{
//							piancha_angle_H=Yaw_Control(Current_angle_CH_R,Target_angle_CH_R);
//							HD_left_speed = 	HD_Speed - KP_hd*piancha_angle_H;  
//							HD_right_speed =	HD_Speed + KP_hd*piancha_angle_H;
//						
//							motor_setPWM_fangxiang(HD_left_speed,HD_right_speed);
//			}
			HD_time++;
			motor_setPWM_fangxiang(1000,1200);
			if(HD_time>=20)
			{
							right_huan=0;
							flag_HD_R = 4;
							//flag_filish = 1;
							index_R = 0;
							HD_time=0;
			}
	
		}

}

int Velocity_Control_L(int encoder)
{  
    static int Encoder,Encoder_Integral,Encoder_error_last;
    int Velocity, Encoder_error, Encoder_Least;                                                  //�ٶ��˲�  
	Encoder_Least = encoder;                                                 //�ٶ��˲�  
	Encoder *= 0.3;		                                                       //һ�׵�ͨ�˲���       
	Encoder += Encoder_Least*0.7;                                           //һ�׵�ͨ�˲���    
	Encoder_Integral += (motor_UK_Target_L - Encoder);       
	if(Encoder_Integral > +1500) Encoder_Integral = +1500;                     //�����޷�
	if(Encoder_Integral < -1500) Encoder_Integral = -1500;                     //�����޷�	
	Encoder_error=motor_UK_Target_L - Encoder;
	Velocity = Encoder_error * L_Velocity_KP + Encoder_Integral * L_Velocity_KI + L_Velocity_KD * (Encoder_error - Encoder_error_last);//��ȡ������ֵ
	Encoder_error_last=Encoder_error;
	//		if(Velocity>=Velocity_max)
//		{
//			Velocity=Velocity_max;
//		}
//		else if(Velocity<=-Velocity_max)
//		{
//			Velocity=-Velocity_max;
//		}
			
//			if(Velocity>0) Velocity+=500;
//			else Velocity-=500;

	  return Velocity;
}



int Velocity_Control_R(int encoder)
{  
    static int Encoder,Encoder_Integral,Encoder_error_last;
    int Velocity, Encoder_error, Encoder_Least;                                          //�ٶ��˲�  
	Encoder_Least = encoder;                                                 //�ٶ��˲�  
	Encoder *= 0.3;		                                                       //һ�׵�ͨ�˲���       
	Encoder += Encoder_Least*0.7;                                           //һ�׵�ͨ�˲���    
	Encoder_Integral += (motor_UK_Target_R - Encoder);       
	if(Encoder_Integral > +1500) Encoder_Integral = +1500;                     //�����޷�
	if(Encoder_Integral < -1500) Encoder_Integral = -1500;                     //�����޷�	
	Encoder_error=motor_UK_Target_R - Encoder;
	Velocity = Encoder_error * R_Velocity_KP + Encoder_Integral * R_Velocity_KI + R_Velocity_KD * (Encoder_error - Encoder_error_last);//��ȡ������ֵ
	Encoder_error_last=Encoder_error;

//		if(Velocity>=Velocity_max)
//		{
//			Velocity=Velocity_max;
//		}
//		else if(Velocity<=-Velocity_max)
//		{
//			Velocity=-Velocity_max;
//		}
	
//		if(Velocity>0) Velocity+=500;
//			else Velocity-=500;

		
	  return Velocity;
}



//int Velocity_SlowControl_L(int encoder)
//{  
//    static int Encoder,Encoder_Integral,Encoder_error_last;
//    int Velocity, Encoder_error, Encoder_Least;                                          //�ٶ��˲�  
//	Encoder_Least = encoder;                                                 //�ٶ��˲�  
//	Encoder *= 0.3;		                                                       //һ�׵�ͨ�˲���       
//	Encoder += Encoder_Least*0.7;                                           //һ�׵�ͨ�˲���    
//	Encoder_Integral += Encoder;       
//	if(Encoder_Integral > +1500) Encoder_Integral = +1500;                     //�����޷�
//	if(Encoder_Integral < -1500) Encoder_Integral = -1500;                     //�����޷�	
//	Encoder_error= motor_UK_Target_R - Encoder;
//	Velocity = Encoder_error * R_Velocity_KP + Encoder_Integral * R_Velocity_KI + R_Velocity_KD * (Encoder_error - Encoder_error_last);//��ȡ������ֵ
//	Encoder_error_last=Encoder_error;	
//	  return Velocity;
//}

//int Velocity_SlowControl_R(int encoder)
//{  
//    static int Encoder,Encoder_Integral,Encoder_error_last;
//    int Velocity, Encoder_error, Encoder_Least;                                          //�ٶ��˲�  
//	Encoder_Least = encoder;                                                 //�ٶ��˲�  
//	Encoder *= 0.3;		                                                       //һ�׵�ͨ�˲���       
//	Encoder += Encoder_Least*0.7;                                           //һ�׵�ͨ�˲���    
//	Encoder_Integral += (motor_UK_Target_R - Encoder);       
//	if(Encoder_Integral > +1500) Encoder_Integral = +1500;                     //�����޷�
//	if(Encoder_Integral < -1500) Encoder_Integral = -1500;                     //�����޷�	
//	Encoder_error=motor_UK_Target_R - Encoder;
//	Velocity = Encoder_error * R_Velocity_KP + Encoder_Integral * R_Velocity_KI + R_Velocity_KD * (Encoder_error - Encoder_error_last);//��ȡ������ֵ
//	Encoder_error_last=Encoder_error;	
//	  return Velocity;
//}

int Yaw_Control(float currentAngle,float targetAngle)//�Ƕȱջ�
{

    static float integral_angle = 0;
    static float lastError_angle = 0;
		float error_angle = 0	;
		float control_signal = 0;
	
		
    error_angle = targetAngle-currentAngle;
		//
		if(error_angle>0)
		{
			if(abs(error_angle)>180)
			{
				error_angle = abs(error_angle)-360;
			}
			
		}
			else
			{
				if(abs(error_angle)>180)
				{
					error_angle =360 - abs(error_angle);
				}
			}
//		if(error_angle < -180 || arror_angle >180)
//		{
//			error_angle = 360-currentAngle+targetAngle;
//		}
//		else if(error_angle > -180 || arror_angle <180)
//		{
//			error_angle = error_angle;
//		}
//		
		//
    integral_angle += error_angle;

    lastError_angle = error_angle;
		
		if(integral_angle>+40) integral_angle = +40;
		if(integral_angle<-40) integral_angle = -40;
			
		
    control_signal = Kp_angle * error_angle + Ki_angle * integral_angle + Kd_angle * (error_angle - lastError_angle);
		
    return control_signal;
}


/************����Ԫ��******************/







/*********************
* ������ƺ��� 
* λ��ʸPD����
*********************/
//int Direction_Control(int errors)
//{
//	float PWM;
//	static	float last_errors;
//	PWM=ADC_KP_1and3_wang*errors+ADC_KD_1and3_wang*last_errors/10;
//	last_errors=errors;
//	return (int)PWM;
//}
//	if((left_V+right_V)<left_right_min)
//	{
//		if(left_V>right_V)
//		{
//			ADC_error_1and3=80;
//		}
//		if(right_V>left_V)
//		{
//			ADC_error_1and3=-80;
//		}
//		PID_error=ADC_KP_1and3_zhi*ADC_error_1and3+ADC_KD_1and3_zhi*(ADC_error_1and3-ADC_error_1and3_last);
//		motor_L=motor_UK-PID_error;
//		motor_R=motor_UK+PID_error;
//		
//	}
//	else if(left_V>L_zhixian && right_V>R_zhixian)    //ֱ�ߴ���
//	{
//		ADC_error_1and3=normalize_data_1and3()+PD_error;
////		PID_error=ADC_KP_1and3_zhi*ADC_error_1and3+ADC_KD_1and3_zhi*(ADC_error_1and3-ADC_error_1and3_last);
////		motor_L=motor_UK-PID_error;
////		motor_R=motor_UK+PID_error;
//			MotorDuty1 = Velocity_Control_L(abs(ECPULSE1)) ;
//			MotorDuty2 = Velocity_Control_R(abs(ECPULSE2));
//	}
//	else     //�������
//	{
//		ADC_error_1and3=normalize_data_1and3()+PD_error;
////		PID_error=ADC_KP_1and3_wang*ADC_error_1and3+ADC_KD_1and3_wang*(ADC_error_1and3-ADC_error_1and3_last);
////		motor_L=motor_UK-PID_error;
////		motor_R=motor_UK+PID_error;
//			MotorDuty1 = Velocity_Control_L(abs(ECPULSE1)); 
//			MotorDuty2 = Velocity_Control_R(abs(ECPULSE2));
//		
//	}



////KP�Ǽ��ٶ� KIԽ�󣬵õ���ֵԽ��
//�������ٶ�190
//int L_Velocity_KP=-38,L_Velocity_KI=-7.7;    // �ٶȱջ���ʵ����Ҫ���ڣ�Ħ������һ������ֵҲ��һ��
//int R_Velocity_KP=-38,R_Velocity_KI=-7.7;    // �ٶȱջ���ʵ����Ҫ���ڣ�Ħ������һ������ֵҲ��һ��   