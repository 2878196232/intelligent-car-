#include "headfile.h"
#include "key.h"

float  P1_jia= 0.1 ;
float  P2_jia= 0.0001 ;	
float  D1_jia= 1 ;
float  D2_jia= 0.1 ; 	

int PD_zhuan=0;

void buzzer_Init()
{
	gpio_mode(P2_6,GPO_PP);
}

void Key_init()
{
	gpio_mode(P7_3,GPIO);   //key1
	gpio_mode(P7_1,GPIO);		//key2
	gpio_mode(P7_2,GPIO);		//key3
	gpio_mode(P7_0,GPIO);		//key4
	
}


key_enum key_scan()
{
	if(P73==0)
	{
		delay_ms(20);
		return key_1;
	}		
	if(P71==0)
	{
		delay_ms(20);
		return key_2;
	}
	if(P72==0)
	{
		delay_ms(20);
		return key_3;
	}
	if(P70==0)
	{
		delay_ms(20);
		return key_4;
	}
	
	return key_null;
}

void menu()
{
	//��ȡ�˵�
	static int i=0;  
	static unsigned char flag = 0;
	if(key_scan()==key_1)
	{
		i=(i+1)%4;
	}
	
	if(key_scan()==key_4)
	{
		PD_zhuan=(PD_zhuan+1)%3;
		if(PD_zhuan != 2)
			flag = 0;
	}
	
//	if(key_scan()==key_2)
//	{
//		if(--i<0)
//		{
//			i+=4;
//		}
//	}
	
	if(PD_zhuan==0)
	{
		oled_p6x8str(96,5,"PD1");
	}
	else if(PD_zhuan==1)
	{
		oled_p6x8str(96,5,"PD2");
	}
	else if(PD_zhuan==2)
	{
		oled_p6x8str(96,5,"speed");
		if(flag == 0)
		{
//			oled_fill_spi(0x00);
			flag = 1;
		}
	}
	
	if(PD_zhuan==0)
	{
		//�����Ӽ�
		//0-7��
		if(i==0)
		{
			oled_p6x8str(64,5,"P1");
			if(key_scan()==key_2)  //������
			{
				zhuanXiangPID_P1+=P1_jia;
			}
			if(key_scan()==key_3)  //������
			{
				zhuanXiangPID_P1-=P1_jia;
			}
			
		}
		if(i==1)
		{
			oled_p6x8str(64,5,"P2");
			
			if(key_scan()==key_2)  //������
			{
				zhuanXiangPID_P2+=P2_jia;
			}
			if(key_scan()==key_3)  //������
			{
				zhuanXiangPID_P2-=P2_jia;
			}
		}
		if(i==2)
		{
			oled_p6x8str(64,5,"D1");
			
			if(key_scan()==key_2)  //������
			{
				zhuanXiangPID_D1+=D1_jia;
			}
			if(key_scan()==key_3)  //������
			{
				zhuanXiangPID_D1-=D1_jia;
			}
			
			
		}
		if(i==3)
		{
			oled_p6x8str(64,5,"D2");
			
			if(key_scan()==key_2)  //������
			{
				zhuanXiangPID_D2+=D2_jia;
			}
			if(key_scan()==key_3)  //������
			{
				zhuanXiangPID_D2-=D2_jia;
			}
			
			
		}
		
		//oled��ʾ
		if(PD_zhuan != 2)
		{
			oled_printf_float(0,6,zhuanXiangPID_P1,2,5);
			oled_printf_float(64,6,zhuanXiangPID_P2,2,5);
			oled_printf_float(0,7,zhuanXiangPID_D1,2,5);
			oled_printf_float(64,7,zhuanXiangPID_D2,2,5);
		}
		
	}
	
	if(PD_zhuan==1)
	{
		//�����Ӽ�
		//0-7��
		if(i==0)
		{
			oled_p6x8str(64,5,"P1");
			
		
			if(key_scan()==key_2)  //������
			{
				zhuanXiangwangPID_P1+=P1_jia;
			}
			if(key_scan()==key_3)  //������
			{
				zhuanXiangwangPID_P1-=P1_jia;
			}
			
		}
		if(i==1)
		{
			oled_p6x8str(64,5,"P2");
			
			if(key_scan()==key_2)  //������
			{
				zhuanXiangwangPID_P2+=P2_jia;
			}
			if(key_scan()==key_3)  //������
			{
				zhuanXiangwangPID_P2-=P2_jia;
			}
		}
		if(i==2)
		{
			oled_p6x8str(64,5,"D1");
			
			if(key_scan()==key_2)  //������
			{
				zhuanXiangwangPID_D1+=D1_jia;
			}
			if(key_scan()==key_3)  //������
			{
				zhuanXiangwangPID_D1-=D1_jia;
			}
			
			
		}
		if(i==3)
		{
			oled_p6x8str(64,5,"D2");
			
			if(key_scan()==key_2)  //������
			{
				zhuanXiangwangPID_D2+=D2_jia;
			}
			if(key_scan()==key_3)  //������
			{
				zhuanXiangwangPID_D2-=D2_jia;
			}
			
			
		}
		
		//oled��ʾ
		
		oled_printf_float(0,6,zhuanXiangwangPID_P1,2,5);
		oled_printf_float(64,6,zhuanXiangwangPID_P2,2,5);
		oled_printf_float(0,7,zhuanXiangwangPID_D1,2,5);
		oled_printf_float(64,7,zhuanXiangwangPID_D2,2,5);
	}
	if(PD_zhuan==2)
	{
		if(key_scan()==key_1)
		{
			motor_UK += 5;
		}
		if(key_scan()==key_2)
		{
			motor_UK -= 5;
		}
		oled_printf_float(0,6,motor_UK,2,5);
	}
}



