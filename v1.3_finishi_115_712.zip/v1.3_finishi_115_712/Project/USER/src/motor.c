#include "motor.h"

/********��������*******/
//����������.��ʵ�ٶ�


#define max_pwm 8500 //6000

int lingshi=0;

void ctimer_init()
{
	gpio_mode(P3_5,GPO_PP);
	gpio_mode(P5_3,GPO_PP);
	ctimer_count_init(CTIM3_P04);
	ctimer_count_init(CTIM0_P34);
	
}


void	ctimer_find(int *numL,int *numR)	//������������ɼ�������ٶ�//
{
	


	 if(DIR_left == 1)    
		{
				lingshi=ctimer_count_read(CTIM0_P34);
				*numL=lingshi;
		}
		else                  
		{
				lingshi=ctimer_count_read(CTIM0_P34);
				*numL=-lingshi;
		}
		if(DIR_right == 1)    
		{
				lingshi=ctimer_count_read(CTIM3_P04);
				*numR=-lingshi;
		}
		else                  
		{
				lingshi=ctimer_count_read(CTIM3_P04);
				*numR=lingshi;
		}				
	 ctimer_count_clean(CTIM3_P04);
	 ctimer_count_clean(CTIM0_P34);
}


void motor_init()
{
	gpio_mode(P6_6,GPO_PP);
	gpio_mode(P6_2,GPO_PP);
	pwm_init(PWMA_CH1P_P60,2000,0);   //���Ƶ�ʸ�Ϊ2000HZ
	pwm_init(PWMA_CH3P_P64,2000,0);
}

void motor_setPWM(int pwmL,int dirtL,int pwmR,int dirtR)
{
	if(pwmL>=max_pwm)
	{
		pwmL = max_pwm;
	}
	else if(pwmL <= 0)
	{
		pwmL = 0;
	}

	if(pwmR>=max_pwm)
	{
		pwmR = max_pwm;
	}
	else if(pwmR <= 0)
	{
		pwmR = 0;
	}
	
	
	if(dirtL == 1)
	{
		P62 = 1;
	}
	else
	{
		P62 = 0;
	}
	
	if(dirtR == 1)
	{
		P66 = 1;
	}
	else
	{
		P66 = 0;
	}

	pwm_duty(PWMA_CH1P_P60,pwmL);
	pwm_duty(PWMA_CH3P_P64,pwmR);
}


void motor_setPWM_fangxiang(int motorA,int motorB)
{
	if(motorA<0)
	{
		motorA=-motorA;
		P62=0;
	}
	else
	{
		P62=1;
	}
	
	if(motorB<0)
	{
		motorB=-motorB;
		P66=0;
	}
	else
	{
		P66=1;
	}
	
	if(motorA>=max_pwm)
	{
		motorA=max_pwm;
	}
	
	if(motorB>=max_pwm)
	{
		motorB=max_pwm;
	}
	
	pwm_duty(PWMA_CH1P_P60,motorA);
	pwm_duty(PWMA_CH3P_P64,motorB);
	
}


