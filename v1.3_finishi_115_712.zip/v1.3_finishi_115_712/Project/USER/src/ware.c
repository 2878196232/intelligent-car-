#include "ware.h"

/*
*	һ�׵�ͨ�˲�
*	parameter:�����˲����ݣ�integer��
*   return:�˲��������
*/

int LeftlowPassFiltering(int Data)
{
	static int lastData = 0;
	int outputData = 0;
	outputData = (int)(lastData * 0.7 + Data * 0.3);
	lastData = Data;
	return outputData;
}

int RightlowPassFiltering(int Data)
{
	static int lastData = 0;
	int outputData = 0;
	outputData = (int)(lastData * 0.7 + Data * 0.3);
	lastData = Data;
	return outputData;
}

int TurnlowPassFiltering(int Data)
{
	static int lastData = 0;
	int outputData = 0;
	outputData = (int)(lastData * 0.7 + Data * 0.3);
	lastData = Data;
	return outputData;
}

/*
*	��ֵ�˲�
*	parameter:��ȡ�����ݣ�integer��
*   return:�˲��������
*/

#define N 5 //���ڴ�С

signed long filter(signed long Data)
{
   static signed long value_buf[N];
   signed long temp = 0;
   static char count = 0;
   char i,j;
   value_buf[count] = Data;
   if(++count == N)count = 0;
   for (j=0;j<N-1;j++)//ð������ȡ��ֵ
   {
      for (i=0;i<N-j;i++)
      {
         if ( value_buf[i]>value_buf[i+1] )
         {
             temp = value_buf[i];
             value_buf[i] = value_buf[i+1];
             value_buf[i+1] = temp;
         }
      }
   }
   return value_buf[(N-1)/2];
}