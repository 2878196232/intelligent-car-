#include "oled.h"
#include "adc.h"
#include "control.h"
#include "motor.h"
#include "SEEKFREE_WIRELESS.h"
#include "headfile.h"
#include "math.h"
//#include <stdarg.h>
#include <string.h>


int ADC1L,ADC1R;
int ADC2L,ADC2R;
int ADC3L,ADC3R;

int normalize_1;
int normalize_2;
int normalize_3;

extern int left_huan;
extern int right_huan;
extern float error;

extern int sum_Left;
extern int sum_Right;


extern uint8 Obstacle_Step;			

float ADC_KP_1and3=42.5;//42.5
float ADC_KD_1and3=400;//300

extern int32 ADC_error_1and3;
extern int32 PID_error;

extern float aver_normalize;

extern float aver_dataL;
extern float aver_dataR;
extern float aver_count;
#define ADC_KP_1    500		//KP1 ָ����Ȩ  7.6	



extern int motor_L;
extern int motor_R;

extern int ECPULSE1;          // �����������ȫ�ֱ���
extern int ECPULSE2; 

extern int ADC1_exp;

extern int sum1,sum2;

int st=1888;
char ascii_buffer[20];

void show()
{
	
//	
//	PID_error=ADC_KP_1and3*ADC_error_1and3+ADC_KD_1and3*(ADC_error_1and3-ADC_error_1and3_last);
	//oled_int16(1,1,ADC_error_1and3);
	
//	
	oled_int16(64,1,dl1b_distance_mm);
//	oled_int16(1,4,sum_Left);
//	oled_int16(64,4,sum_Right);	
//		oled_int16(1,5,left_huan);	
//		oled_int16(64,5,right_huan);
	oled_printf_int32(1,1,ADC_error_1and3,8); 
//	oled_int16(64,1,num_pitch);
	oled_int16(1,3,fabs(Current_angle_CH_R -Target_zj_L));
	oled_int16(64,3,Obstacle_Step);
//	oled_int16(1,4,sum_Left);
//	oled_int16(64,4,sum_Right);


//	oled_int16(1,5,left_huan);
//	oled_int16(64,5,right_huan);


//	oled_int16(1,6,ECPULSE1);
//	oled_int16(64,6,ECPULSE2);
//	
//	
//	sprintf(ascii_buffer, "%d", st);
//	
//	wireless_uart_send_buff(ascii_buffer,10);
	
	//oled_printf_float(64,7,a);
//	ADC_error_1and3=ADC_error_1and3_last;
	
//	oled_int16(1,5,(int)aver_dataL);
//	oled_int16(64,5,(int)aver_dataR);
//	(normalize_date(select_ADC_2))
//	oled_int16(1,5,normalize_date(select_ADC_2));
//	oled_int16(64,5,normalize_date(select_ADC_3));
	//oled_int16(1,6,ADC_KP_1*((aver_dataL-aver_dataR)/(aver_dataL+aver_dataR)));
//	
//	
	
//	date(select_ADC_1,&ADC1L,&ADC1R);
//	date(select_ADC_2,&ADC2L,&ADC2R);
//	date(select_ADC_3,&ADC3L,&ADC3R);
//	normalize_1=normalize_date(select_ADC_1);
//	normalize_2=normalize_date(select_ADC_2);
//	normalize_3=normalize_date(select_ADC_3);
//			//normalize_3=normalize_date(select_ADC_2);
////		oled_int16(64,1,normalize_3);
//		
//		oled_int16(1,1,ADC1L);
//		oled_int16(64,1,ADC1R);
//		oled_int16(1,2,ADC1L-ADC1R);
////			oled_int16(64,2,ADC1L+ADC1R);
////		oled_int16(64,2,normalize_1);

////		ctimer_count_read(CTIM3_P04)
//		
//  	oled_int16(1,3,ADC2L);
//		oled_int16(64,3,ADC2R);
//		oled_int16(1,4,ADC2L-ADC2R);
////			oled_int16(64,4,ADC2L+ADC2R);
////		oled_int16(64,4,normalize_2);
//		
//		oled_int16(1,5,ADC3L);
//		oled_int16(64,5,ADC3R);
//		oled_int16(1,6,ADC3L-ADC3R);
////			oled_int16(64,6,ADC3L+ADC3R);
//			
////			oled_int16(1,7,error);
			
//			oled_int16(1,7,ADC1L+ADC2L+ADC3L);
//			oled_int16(64,7,ADC1R+ADC2R+ADC3R);

//	wireless_show();
//	wireless_uart_send_buff
	
}


void wireless_show()
{
	
	wireless_uart_send_buff("EC1:",4);
	sprintf(ascii_buffer, "%d",sum1);
	wireless_uart_send_buff(ascii_buffer,5);
	wireless_uart_send_buff("  ",2);
	
	wireless_uart_send_buff("EC2:",4);
	sprintf(ascii_buffer, "%d",sum1);
	wireless_uart_send_buff(ascii_buffer,5);
	wireless_uart_send_buff("  ",2);
	
	wireless_uart_send_buff("MO1:",4);
	sprintf(ascii_buffer, "%d",motor_L);
	wireless_uart_send_buff(ascii_buffer,5);
	wireless_uart_send_buff("  ",2);
	
	wireless_uart_send_buff("MO2:",4);
	sprintf(ascii_buffer, "%d",motor_R);
	wireless_uart_send_buff(ascii_buffer,5);
	wireless_uart_send_buff("  ",2);
	
//	date(select_ADC_1,&ADC1L,&ADC1R);
//	date(select_ADC_2,&ADC2L,&ADC2R);
//	date(select_ADC_3,&ADC3L,&ADC3R);
//	normalize_1=normalize_date(select_ADC_1);
//	normalize_2=normalize_date(select_ADC_2);
//	normalize_3=normalize_date(select_ADC_3);
//	
//	
//	wireless_uart_send_buff("ADC1:",5);
//	sprintf(ascii_buffer, "%d",ADC1L);
//	wireless_uart_send_buff(ascii_buffer,5);
//	wireless_uart_send_buff("  ",2);

//	
//	sprintf(ascii_buffer, "%d",ADC1R);
//	wireless_uart_send_buff(ascii_buffer,5);
//	wireless_uart_send_buff("  ",2);
//	
//	sprintf(ascii_buffer, "%d",ADC1L-ADC1R);
//	wireless_uart_send_buff(ascii_buffer,5);
//	wireless_uart_send_buff("\n\n",2);
//	
//	wireless_uart_send_buff("ADC2:",5);
//	sprintf(ascii_buffer, "%d",ADC2L);
//	wireless_uart_send_buff(ascii_buffer,5);
//	wireless_uart_send_buff("  ",2);

//	
//	sprintf(ascii_buffer, "%d",ADC2R);
//	wireless_uart_send_buff(ascii_buffer,5);
//	wireless_uart_send_buff("  ",2);
//	
//	sprintf(ascii_buffer, "%d",ADC2L-ADC2R);
//	wireless_uart_send_buff(ascii_buffer,5);
//	wireless_uart_send_buff("\n\n",2);
//	
//	wireless_uart_send_buff("ADC3:",5);
//	sprintf(ascii_buffer, "%d",ADC3L);
//	wireless_uart_send_buff(ascii_buffer,5);
//	wireless_uart_send_buff("  ",2);

//	
//	sprintf(ascii_buffer, "%d",ADC3R);
//	wireless_uart_send_buff(ascii_buffer,5);
//	wireless_uart_send_buff("  ",2);
//	
//	sprintf(ascii_buffer, "%d",ADC3L-ADC3R);
//	wireless_uart_send_buff(ascii_buffer,5);
//	wireless_uart_send_buff("\n\n",2);
	
//	sprintf(ascii_buffer, "%d",select_ADC_1);
//	wireless_uart_send_buff(ascii_buffer,5);
//	wireless_uart_send_buff("\n",5);
//	
//	sprintf(ascii_buffer, "%d",select_ADC_2);
//	wireless_uart_send_buff(ascii_buffer,5);
//	wireless_uart_send_buff("\n",5);

	
}

