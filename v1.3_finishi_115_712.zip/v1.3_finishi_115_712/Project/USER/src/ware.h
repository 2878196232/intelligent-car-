#ifndef __WARE_H__
#define __WARE_H__

#include "headfile.h"

int LeftlowPassFiltering(int Data);
int RightlowPassFiltering(int Data);
int TurnlowPassFiltering(int Data);
signed long filter(signed long Data);

#endif