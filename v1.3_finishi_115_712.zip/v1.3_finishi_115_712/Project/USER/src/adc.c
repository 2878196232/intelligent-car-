#include "headfile.h"
#include "adc.h"
#include <math.h>
#define ADC_NUM     12    //һ�βɼ�����

#define ADC_KP_1    1		//
#define ADC_KP_2    5000
#define ADC_KP_3  1

			//L-R=error
#define ADC_error1 0
#define ADC_error2 -10
#define ADC_error3 380

float MAX_esp=7;			//ָ���޷�
float ADC_xianfu=1000;

#define  us      40    //�ɼ��ӳ�40us


int16  adc_data[ADC_NUM][2];                //�����вɼ�ֵ ԭʼֵ8�����

float adc1=0;
//int16  Left_Adc=0,Right_Adc=0;      //           ���ҵ��ֵ

float normal_2;
float normal_2_last;

float normal_2_P=0.2;

float error=0;
float error_last=0;
float error_lingshi=0;


float adc_K=0.8;


void ADC_Init_All()
{
	adc_init(ADC_P00,ADC_SYSclk_DIV_32);   //32��Ƶ��750KHZ   1.3us�ɼ�һ��
	adc_init(ADC_P01,ADC_SYSclk_DIV_32);
	adc_init(ADC_P05,ADC_SYSclk_DIV_32);
	adc_init(ADC_P06,ADC_SYSclk_DIV_32);
	adc_init(ADC_P13,ADC_SYSclk_DIV_32);
	adc_init(ADC_P14,ADC_SYSclk_DIV_32);
	adc_init(ADC_P16,ADC_SYSclk_DIV_32);
//	adc_once(ADC_P16,ADC_12BIT)
}

float normalize_data_1and3()
{

			error=1500*normalize_date_xin();
//		error=500*normalize_date_xin()+500*normalize_date(select_ADC_3);
//		error=500*(normalize_date(select_ADC_1)+normalize_date(select_ADC_2)+normalize_date(select_ADC_3))/(ADC_KP_1+ADC_KP_2+ADC_KP_3);

		return error;
	
}


float normalize_date(select_ADC select_ADC)
{
	float maxL=-100,maxR=-100;
	float minL=10000,minR=10000;
	float sumL=0,sumR=0;
	
	int i=0;
	if(select_ADC == select_ADC_1)
	{
		for(i=0;i<ADC_NUM;i++)
		{
			adc_data[i][0]=adc_once(ADC_P00,ADC_12BIT)+ADC_error1;
			adc_data[i][1]=adc_once(ADC_P01,ADC_12BIT);
			maxL=maxL > adc_data[i][0] ? maxL:adc_data[i][0];
			minL=minL < adc_data[i][0] ? minL: adc_data[i][0];
			maxR=maxR > adc_data[i][1] ? maxR:adc_data[i][1];
			minR=minR < adc_data[i][1] ? minR: adc_data[i][1];
			sumL+=adc_data[i][0];
			sumR+=adc_data[i][1];
		}
		sumL=sumL/(ADC_NUM-2);
		sumR=sumR/(ADC_NUM-2);
		return (ADC_KP_1*((sumL)-(sumR))/(sumL+sumR));
	}
	else if(select_ADC == select_ADC_2)
	{
		for(i=0;i<ADC_NUM;i++)
		{
			adc_data[i][0]=adc_once(ADC_P05,ADC_12BIT)+ADC_error2;
			adc_data[i][1]=adc_once(ADC_P06,ADC_12BIT);
			maxL=maxL > adc_data[i][0] ? maxL:adc_data[i][0];
			minL=minL < adc_data[i][0] ? minL: adc_data[i][0];
			maxR=maxR > adc_data[i][1] ? maxR:adc_data[i][1];
			minR=minR < adc_data[i][1] ? minR: adc_data[i][1];
			sumL+=adc_data[i][0];
			sumR+=adc_data[i][1];
		}
		sumL=sumL/(ADC_NUM-2);
		sumR=sumR/(ADC_NUM-2);
		return (ADC_KP_2*((sumL)-(sumR))/(sumL+sumR));
	}
	else if(select_ADC == select_ADC_3)
	{
		for(i=0;i<ADC_NUM;i++)
		{
			adc_data[i][0]=adc_once(ADC_P13,ADC_12BIT)+ADC_error3;
			adc_data[i][1]=adc_once(ADC_P14,ADC_12BIT);
			maxL=maxL > adc_data[i][0] ? maxL:adc_data[i][0];
			minL=minL < adc_data[i][0] ? minL: adc_data[i][0];
			maxR=maxR > adc_data[i][1] ? maxR:adc_data[i][1];
			minR=minR < adc_data[i][1] ? minR: adc_data[i][1];
			sumL+=adc_data[i][0];
			sumR+=adc_data[i][1];
		}
		sumL=sumL/(ADC_NUM-2);
		sumR=sumR/(ADC_NUM-2);
		return (ADC_KP_3*((sumL)-(sumR))/(sumL+sumR));
		}
	else
	{
		
		return 0;
		
	}
}


float normalize_date_xin()
{
	float maxL=-100,maxR=-100;
	float minL=10000,minR=10000;
	float sumADC1L=0,sumADC1R=0;
	float sumADC2L=0,sumADC2R=0; 
	float sumADC3L=0,sumADC3R=0; 
	float sumL=0,sumR=0;
	
	int i=0;
	//ADC1
	{
		for(i=0;i<ADC_NUM;i++)
		{
			adc_data[i][0]=adc_once(ADC_P00,ADC_12BIT)+ADC_error1;
			adc_data[i][1]=adc_once(ADC_P01,ADC_12BIT);
			maxL=maxL > adc_data[i][0] ? maxL:adc_data[i][0];
			minL=minL < adc_data[i][0] ? minL: adc_data[i][0];
			maxR=maxR > adc_data[i][1] ? maxR:adc_data[i][1];
			minR=minR < adc_data[i][1] ? minR: adc_data[i][1];
			sumL+=adc_data[i][0];
			sumR+=adc_data[i][1];
		}
		
		sumADC1L=sumL/(ADC_NUM-2);
		sumADC1R=sumR/(ADC_NUM-2);
		
		
		
	}
	
	//��������
	maxL=-100,maxR=-100;
	minL=10000,minR=10000;
	sumL=0;
	sumR=0;
	
	//ADC2
	{
		for(i=0;i<ADC_NUM;i++)
		{
			adc_data[i][0]=adc_once(ADC_P05,ADC_12BIT)+ADC_error2;
			adc_data[i][1]=adc_once(ADC_P06,ADC_12BIT);
			maxL=maxL > adc_data[i][0] ? maxL:adc_data[i][0];
			minL=minL < adc_data[i][0] ? minL: adc_data[i][0];
			maxR=maxR > adc_data[i][1] ? maxR:adc_data[i][1];
			minR=minR < adc_data[i][1] ? minR: adc_data[i][1];
			sumL+=adc_data[i][0];
			sumR+=adc_data[i][1];
		}
		sumADC2L=sumL/(ADC_NUM-2);
		sumADC2R=sumR/(ADC_NUM-2);
		
	}
	
	//��������
	maxL=-100,maxR=-100;
	minL=10000,minR=10000;
	sumL=0;
	sumR=0;
	
	//ADC3
	{
		for(i=0;i<ADC_NUM;i++)
		{
			adc_data[i][0]=adc_once(ADC_P13,ADC_12BIT)+ADC_error3;
			adc_data[i][1]=adc_once(ADC_P14,ADC_12BIT);
			maxL=maxL > adc_data[i][0] ? maxL:adc_data[i][0];
			minL=minL < adc_data[i][0] ? minL: adc_data[i][0];
			maxR=maxR > adc_data[i][1] ? maxR:adc_data[i][1];
			minR=minR < adc_data[i][1] ? minR: adc_data[i][1];
			sumL+=adc_data[i][0];
			sumR+=adc_data[i][1];
		}
		sumADC3L=sumL/(ADC_NUM-2);
		sumADC3R=sumR/(ADC_NUM-2);
		
	}
//	sumADC1L = filter(sumADC1L);
//	sumADC1R = filter(sumADC1R);
	return (((sqrt(sumADC1L*sumADC1L+ADC_KP_2*sumADC2L+sumADC3L*sumADC3L))-(sqrt(sumADC1R*sumADC1R+ADC_KP_2*sumADC2R+sumADC3R*sumADC3R)))/((sqrt(sumADC1L*sumADC1L+ADC_KP_2*sumADC2L+sumADC3L*sumADC3L))+(sqrt(sumADC1R*sumADC1R+ADC_KP_2*sumADC2R+sumADC3R*sumADC3R))));
	
}

//float normalize_date_xin()
//{
//	float maxL=-100,maxR=-100;
//	float minL=10000,minR=10000;
//	float sumADC1L=0,sumADC1R=0;
//	float sumADC2L=0,sumADC2R=0; 
//	float sumL=0,sumR=0;
//	
//	int i=0;
//	//ADC1
//	{
//		for(i=0;i<ADC_NUM;i++)
//		{
//			adc_data[i][0]=adc_once(ADC_P00,ADC_12BIT)+ADC_error1;
//			adc_data[i][1]=adc_once(ADC_P01,ADC_12BIT);
//			maxL=maxL > adc_data[i][0] ? maxL:adc_data[i][0];
//			minL=minL < adc_data[i][0] ? minL: adc_data[i][0];
//			maxR=maxR > adc_data[i][1] ? maxR:adc_data[i][1];
//			minR=minR < adc_data[i][1] ? minR: adc_data[i][1];
//			sumL+=adc_data[i][0];
//			sumR+=adc_data[i][1];
//		}
//		
//		sumADC1L=sumL/(ADC_NUM-2);
//		sumADC1R=sumR/(ADC_NUM-2);
//		
//		
//		
//	}
//	
//	//��������
//	maxL=-100,maxR=-100;
//	minL=10000,minR=10000;
//	sumL=0;
//	sumR=0;
//	
//	//ADC2
//	{
//		for(i=0;i<ADC_NUM;i++)
//		{
//			adc_data[i][0]=adc_once(ADC_P05,ADC_12BIT)+ADC_error2;
//			adc_data[i][1]=adc_once(ADC_P06,ADC_12BIT);
//			maxL=maxL > adc_data[i][0] ? maxL:adc_data[i][0];
//			minL=minL < adc_data[i][0] ? minL: adc_data[i][0];
//			maxR=maxR > adc_data[i][1] ? maxR:adc_data[i][1];
//			minR=minR < adc_data[i][1] ? minR: adc_data[i][1];
//			sumL+=adc_data[i][0];
//			sumR+=adc_data[i][1];
//		}
//		sumADC2L=sumL/(ADC_NUM-2);
//		sumADC2R=sumR/(ADC_NUM-2);
//		
//	}
////	sumADC1L = filter(sumADC1L);
////	sumADC1R = filter(sumADC1R);
//	return (((ADC_KP_1*sqrt(sumADC1L*sumADC1L+sumADC2L*sumADC2L))-(ADC_KP_2*sqrt(sumADC1R*sumADC1R+sumADC2R*sumADC2R)))/((sqrt(sumADC1L*sumADC1L+sumADC2L*sumADC2L))+(sqrt(sumADC1R*sumADC1R+sumADC2R*sumADC2R))));
//	
//}




void normalize_date_All(int16 *ADC1,int16 *ADC2,int16 *ADC3)
{
	*ADC1=normalize_date(select_ADC_1);
	*ADC2=normalize_date(select_ADC_2);
	*ADC3=normalize_date(select_ADC_3);
}

void date(select_ADC select_ADC,int16 *ADCL,int16 *ADCR)
{
	if(select_ADC==select_ADC_1)
	{
		*ADCL=adc_once(ADC_P00,ADC_12BIT)+ADC_error1;
		*ADCR=adc_once(ADC_P01,ADC_12BIT);
	}
	else if(select_ADC==select_ADC_2)
	{
		*ADCL=adc_once(ADC_P05,ADC_12BIT)+ADC_error2;
		*ADCR=adc_once(ADC_P06,ADC_12BIT);
	}
	else if(select_ADC==select_ADC_3)
	{
		*ADCL=adc_once(ADC_P13,ADC_12BIT)+ADC_error3;
		*ADCR=adc_once(ADC_P14,ADC_12BIT);
	}
	
	
}


